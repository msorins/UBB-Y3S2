package main

import (
	"github.com/therecipe/qt/core"
	"github.com/therecipe/qt/quick"
	"github.com/therecipe/qt/widgets"
	"os"
)

type CtxObject struct {
	core.QObject

	_ func() `constructor:"init"`

	_ string `property:"someString"`

	_ func() `signal:"clicked,auto"`
}

func (t *CtxObject) init() {
}

func (t *CtxObject) clicked() {
	println("clicked qml button")
}


func main() {
	core.QCoreApplication_SetAttribute(core.Qt__AA_EnableHighDpiScaling, true)

	app := widgets.NewQApplication(len(os.Args), os.Args)
	view := quick.NewQQuickView(nil)
	view.SetTitle("bridge Example")
	view.SetResizeMode(quick.QQuickView__SizeRootObjectToView)
	//view.RootContext().SetContextProperty("ctxObject", NewCtxObject(nil))
	view.SetSource(core.QUrl_FromLocalFile("./qml/main.qml"))
	app.Exec()
}