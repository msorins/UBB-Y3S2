package balarie.features.search;

import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Issue;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Pending;
import net.thucydides.core.annotations.Steps;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

import balarie.steps.serenity.EndUserSteps;

@RunWith(SerenityRunner.class)
public class TestAddStudentWeb {

    @Managed(uniqueSession = true)
    public WebDriver webdriver;

    @Steps
    public EndUserSteps anna;

    @Test
    public void addStudentCorrect() {
        anna.is_the_home_page();
        anna.AddUser("Naomi", "naomi@gmail.com", "935", "Cipri Tutorele");
    }


    @Test
    public void addStudentIncorect() {
        anna.is_the_home_page();
        anna.DoNotAddUser("Naomi", "naomi@gmail.com", "alabama", "Cipri Tutorele");
    }


} 